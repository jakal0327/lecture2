var express=require('express')
var app= express()
require('dotenv')


var port=process.env.PORT || 3000;
app.listen(port,()=>{
    console.log(`Sever is Stating at http://localhost:${port}`)
})

app.get('/a',function(req,res){
    res.send('<img src="./horse.png" alt="경로문제야?">')
})