var express =require('express')
var app = express()
var path= require('path')

app.set('views',path.join(__dirname,'views'))

app.use((req,res)=>{
    console.log("첫번째 미들웨어 요청.")
var userAgent = req.header('User-Agent')
var parName = req.query.name;
    res.writeHead('200',{'Content-Type':'text/html;charset=utf8'})
    res.write('<h1>Express 서버에서 응답한 결과</h1>')
    res.write(`<div><p>User-Agent:${userAgent}</p></div`)
    res.write(`<div><p>Param Name:${userAgent}</p></div`)

})

var port = process.env.PORT || 3000
app.listen(port, ()=>{
    console.log('Sever is Strating at:http://localhost:%d',port)
})