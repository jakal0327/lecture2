var express = require('express')
var app = express()
var path = require('path')
var ejs=require('ejs')
var dotenv=require('dotenv').config()
var indexRouter=require('./router/index')
var mainRouter=require('./router/main')
// dotEnv.config()
// var router = require('./router/main.js')(app)
// require('./router/index')
// require('dotenv').config()

app.set('views', path.join(__dirname,'views'))
app.set('view engine', 'ejs')
// app.engine('html', require('ejs').renderFile)

app.use(express.static(path.join(__dirname,'public')))
app.use('/',indexRouter) 
app.use('/main',mainRouter) 

var port = process.env.PORT || 3000;

// listen(port,url,backloh,callback function)
app.listen(port, ()=>{
    console.log(`Server is Starting : http://localhost:${port}`)
})