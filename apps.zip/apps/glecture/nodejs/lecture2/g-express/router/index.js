var express = require('express');
var router = express.Router();
router.get('/hello' ,(req, res)=>{
    console.log(req.query)
})
router.get('/about' , (req , res)=>{
    res.render('index')
})
module.exports =router;