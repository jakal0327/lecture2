var express = require('express');
var router = express.Router();
router.get('/hello' ,(req, res)=>{
    console.log(req.query)
})
var dataArray=['사과','배','바나나','포도','망고']
router.get('/about' , (req , res)=>{
    res.render('index',{
        name:"Kim",
        title:"반갑습니다.",data:dataArray
    })
})
module.exports =router;