var express = require('express')
var app=express()
var path=require('path')
require('dotenv').config()
var ejs=require('ejs')
   , static = require('serve-static') // ,붙이면 위에 var 자동적용
     bodyParser=require('body-parser')



app.set('views',path.join(__dirname,'views'))
app.set('view engine','ejs')

//body-parser을 이용 해 application/x-www-form-urlencoded 파싱
app.use(static(path.join(__dirname,'public')))
app.use(bodyParser.urlencoded({extends:false}))

app.use((req,res)=>{
var paramId =req.body.id || req.query.id
var paramPs =req.body.pass || req.query.pass
res.writeHead('200',{'Content-Type':'text/html;charset=utf8'})
res.write("<h1>서버가 응답한 결과. </h1>")
res.write("<div><p> ParamId: '+paramId+'</p></div>")
res.write("<div><p> ParamPs: '+paramPs+'</p></div>")
res.end();
})

var port =process.env.PORT || 3000;
app.listen(port,()=>{
    console.log(`Server is Starting at http://localhost:${port}`)
})