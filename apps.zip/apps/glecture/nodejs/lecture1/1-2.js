var http=require('http')

var app =http.createServer()

var port=3000;
app.listen(port,()=>{
    console.log(`웹서버 시작:http://localhost:${port}`)
});


