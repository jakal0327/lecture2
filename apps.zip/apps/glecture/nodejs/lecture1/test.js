var a= "ㅎㅇ";
var b= "mkdㅂㅇ";
var c= a+b;
console.log(c)

