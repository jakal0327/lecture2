//타사이트에서 http를 활용한 데이터 가져오기
var http = require('http')
var Options={
    host:'www.google.com',
    port:80,
    path:'/'
}
var req=http.get(option,(res)=>{
    var resData = '';
    res.on('data',(chunk)=>{
        resData += chunk;
})
res.on('end',()=>{
    console.log(resData)
})
})
req.on('error', (err)=>{
    console.log("에러 발생"+ err.message)
})