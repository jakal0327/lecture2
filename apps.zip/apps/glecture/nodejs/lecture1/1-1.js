var http=require('http')

var sever =http.createServer()

var port=8000;
sever.listen(port,function(){
    console.log('sever on:http://localhost:'+port)
});
