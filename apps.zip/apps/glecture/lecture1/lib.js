function over(obj) {
    obj.src="./banana.png";
    }
function out(obj) {
    obj.src="./apple.png";
    }

var a = 3;
let b = 4;
const c = Document.write("fjwepw")
