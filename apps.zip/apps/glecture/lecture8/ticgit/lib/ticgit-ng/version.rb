module TicGitNG
  VERSION = '1.0.2.2'
end
