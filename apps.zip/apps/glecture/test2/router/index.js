

router.get(['topic','/topic/:id'],(res,req)=>{

    var sql="SELECT * FROM topic";

    db.query(sql,(err,results)=>{

        var id=req.params.id
        if(id){


        }_
        var sql='SELECT*FROM topic WHERE id=?'

        db.query(sql,[id],(err,result)=>{
            if(!err){

                res.render('view',{topics:results,})
            }else{
                console.log(err);
                res.status(500).send("Internal Server Error")
            }


        })

    }else{

        res.render('view',{topics"results,topic:undefined})
    }

    })


})